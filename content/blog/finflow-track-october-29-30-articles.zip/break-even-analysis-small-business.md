---
title: "Break-Even Analysis for Small Business: How to Calculate Your Break-Even Point"
description: "Learn the break-even formula for small businesses, calculate the sales volume and revenue needed to cover costs, and test how price and costs change the result."
slug: "break-even-analysis-small-business"
author: "FinFlowTrack Editorial Team"
publishedAt: "2026-10-29"
updatedAt: "2026-10-29"
category: "small-business-finance"
tags:
  - break-even analysis
  - break-even point formula
  - contribution margin
  - small business finance
  - business planning
featured: false
draft: false
---

# Break-Even Analysis for Small Business: How to Calculate Your Break-Even Point

A business can make sales and still lose money. Rent, salaries, software, materials, delivery costs, and payment fees all affect whether revenue is enough to cover the cost of operating. Break-even analysis helps answer a practical question: **How much must the business sell during a specific period to cover its costs?**

The break-even point is where total revenue equals total costs. At that level, the business has neither an operating profit nor an operating loss under the assumptions used in the calculation.

## Break-even point: the quick answer

For one product or service:

**Break-even units = Fixed costs ÷ (Selling price per unit − Variable cost per unit)**

The amount in brackets is the **contribution margin per unit**.

To calculate break-even sales revenue:

**Break-even sales revenue = Fixed costs ÷ Contribution margin ratio**

Use figures from the same time period. If fixed costs are monthly, the result is a monthly break-even target.

## Understand the numbers

### Fixed costs

Fixed costs generally stay the same within a relevant operating range during the period being analysed, even if sales volume changes. Examples include premises rent, fixed salaries, insurance, software subscriptions, and equipment lease payments. Costs may change when the business expands or passes a capacity threshold, so review assumptions regularly.

### Variable costs

Variable costs change with the number of products sold or services delivered. Examples include materials, packaging, per-order delivery, sales commissions, and payment-processing charges that vary with transaction value.

Some costs are mixed. A utility bill may include a fixed connection charge and a usage-based component. Separate the fixed and variable portions where practical.

### Selling price and contribution margin

Selling price per unit is the amount of revenue earned from one unit or service. Be consistent about discounts, refunds, sales taxes, and how revenue is recorded.

**Contribution margin per unit = Selling price per unit − Variable cost per unit**

Contribution margin first covers fixed costs. Once total contribution has covered fixed costs, additional contribution increases operating profit, assuming other costs and conditions remain unchanged.

## How to calculate break-even point in units

1. Choose a period, such as one month.
2. Add the fixed costs for that period.
3. Estimate variable cost for one unit.
4. Identify the selling price for one unit.
5. Subtract variable cost from selling price.
6. Divide fixed costs by contribution margin.
7. Round up to the next whole unit if only whole units can be sold.

### Worked example: a small product business

Assume a business sells a product for $40. Its variable cost is $24 per unit, and monthly fixed costs are $2,400.

| Input | Amount |
| --- | ---: |
| Selling price per unit | $40 |
| Variable cost per unit | $24 |
| Contribution margin per unit | $16 |
| Monthly fixed costs | $2,400 |

Contribution margin: $40 − $24 = $16.

Break-even units: $2,400 ÷ $16 = **150 units per month**.

Check the result:

- Revenue: 150 × $40 = $6,000.
- Variable costs: 150 × $24 = $3,600.
- Fixed costs: $2,400.
- Total costs: $3,600 + $2,400 = $6,000.
- Operating result: $6,000 − $6,000 = $0.

Revenue equals total costs, so the calculation balances.

## How to calculate break-even sales revenue

First calculate the contribution margin ratio:

**Contribution margin ratio = Contribution margin per unit ÷ Selling price per unit**

Using the example: $16 ÷ $40 = 0.40, or 40%.

Then:

**Break-even revenue = Fixed costs ÷ Contribution margin ratio**

$2,400 ÷ 0.40 = **$6,000 per month**.

For a business selling several products or services, a single break-even revenue estimate requires a realistic sales mix and a weighted average contribution margin. If the mix changes substantially, the result changes too.

## Break-even analysis for a service business

A service business can use the same logic, but it must define a useful unit: one consulting session, project, billable hour, or completed job.

Imagine a design studio charges $500 for a standard project. Direct project costs average $125. Monthly fixed costs are $3,000.

- Contribution margin per project: $500 − $125 = $375.
- Break-even projects: $3,000 ÷ $375 = **8 projects**.

The studio needs eight comparable projects in the month to cover the costs included. If project scope and direct costs differ materially, calculate separate margins or use a carefully estimated average.

## Build a simple break-even spreadsheet

| Cell | Input | Example |
| --- | --- | ---: |
| B2 | Monthly fixed costs | 2,400 |
| B3 | Selling price per unit | 40 |
| B4 | Variable cost per unit | 24 |
| B5 | Contribution margin | `=B3-B4` |
| B6 | Break-even units | `=B2/B5` |
| B7 | Contribution margin ratio | `=B5/B3` |
| B8 | Break-even revenue | `=B2/B7` |

A spreadsheet formula for whole units is `=ROUNDUP(B6,0)`. Use the unrounded result for analysis and the rounded-up result for planning whole-unit sales. Add a warning if selling price is less than or equal to variable cost: the standard formula cannot produce a meaningful positive sales target when contribution margin is zero or negative.

## What changes the break-even point?

- **Selling price:** A higher price increases contribution margin if costs remain unchanged, but may affect customer demand.
- **Variable costs:** Supplier negotiations, reduced waste, or more efficient delivery may increase contribution margin.
- **Fixed costs:** Lower recurring commitments reduce the contribution needed to cover overhead.
- **Sales mix:** Selling more high-margin products can change the overall break-even point.

Test one assumption at a time and document the change. Do not assume that a price increase or cost reduction will have no effect on demand, quality, or capacity.

## Common break-even mistakes

- **Mixing time periods:** Monthly fixed costs must be compared with monthly contribution.
- **Leaving out costs:** Include direct materials, transaction fees, commissions, and other costs that change with sales.
- **Misclassifying mixed costs:** Separate fixed and variable components where practical.
- **Using an unrealistic price:** Consider discounts, refunds, and the price customers are likely to pay.
- **Ignoring sales mix:** Multiple products may have different contribution margins.
- **Treating break-even as a profit target:** Break-even means zero profit under the model.
- **Treating an estimate as a guarantee:** Demand, supplier prices, and capacity can change.

## Break-even point versus target profit

For one product:

**Units needed for target profit = (Fixed costs + Target operating profit) ÷ Contribution margin per unit**

If fixed costs are $2,400, desired monthly operating profit is $800, and contribution margin is $16:

($2,400 + $800) ÷ $16 = **200 units**.

This is the required volume under the stated assumptions, before costs excluded from the model.

## How often should you update the calculation?

Review it when prices, supplier costs, rent, payroll, insurance, sales mix, discounts, or capacity change. Also review it when planning a new product, location, hire, or equipment purchase. Compare estimates with actual results; break-even analysis is a planning tool, not a replacement for accounting records or financial statements.

## Frequently asked questions

### What is the break-even point in simple terms?

It is the sales level at which total revenue equals total costs for a defined period. The business has covered the costs included but has not yet generated an operating profit from them.

### Can break-even point be a decimal?

Yes. If the business sells whole units, round up to the next whole unit for a practical minimum target.

### What if variable cost is higher than selling price?

Each sale contributes a negative amount before fixed costs. The standard break-even formula cannot produce a meaningful positive sales target. Review price, direct costs, or the product/service model.

### Is break-even analysis the same as cash-flow forecasting?

No. Break-even compares revenue and costs. A cash-flow forecast estimates when money enters and leaves the business. A business can reach accounting break-even and still experience a cash shortage because customers pay late or bills fall due earlier.

### Does it work for multiple products?

Yes, but the calculation needs a realistic sales mix and weighted average contribution margin. Recalculate if the mix changes.

## Turn the calculation into a planning habit

Record your assumptions, compare the result with realistic demand, and revisit the calculation when costs or prices change. Use it alongside a budget and cash-flow forecast rather than treating it as a complete picture of business health.

For the next step, use the [business budget guide](/blog/how-to-create-a-business-budget) to plan expected income and costs, and the [cash flow forecasting guide](/blog/cash-flow-forecasting-small-business) to estimate when money will arrive and leave.

Explore [FinFlow Track](https://www.finflowtrack.com/) and verify current features and plan details against your needs before choosing a workflow.

---

## Sources and further reading

- [U.S. Small Business Administration: Break-Even Point Calculator](https://www.sba.gov/counseling/plan-your-business/break-even-point-calculator/) — unit formula and fixed, variable, and semi-variable costs.
- [U.S. Small Business Administration: Break-Even Point](https://legacy.sba.gov/business-guide/plan-your-business/calculate-your-startup-costs/break-even-point) — unit and revenue calculations, contribution margin ratio, and limitations.
- [Stripe: How do you calculate the break-even point?](https://stripe.com/resources/more/how-to-calculate-the-break-even-point) — additional explanation of unit and revenue calculations.

*Examples are illustrative, not forecasts or financial advice. Actual results depend on cost structure, sales mix, pricing, and period selected.*
